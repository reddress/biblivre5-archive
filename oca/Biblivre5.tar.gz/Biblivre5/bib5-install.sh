#!/bin/bash

if [ "$(id -u)" != "0" ]; then
	echo Executar como root ou sudo $0
	exit
fi
echo "Instalando o Biblivre5..."

# suporte para a lingua portuguesa BR.
apt update
apt -y install `check-language-support -l br`
apt -y install apt firefox-locale-pt
rm -r /var/lib/apt/lists/* -vf

# Corrigindo o encoding do Postgres para poder usar banco de dados latin1 ou outro
cp ./files/environment /etc/
chmod 644 /etc/environment
cp ./files/locale  /etc/default/locale
chmod 644 /etc/default/locale
echo "pt_BR pt_BR.ISO-8859-1" >> /etc/locale.alias
rm /var/lib/locales/supported.d/en
cp ./files/br /var/lib/locales/supported.d/
chmod 644 /var/lib/locales/supported.d/br
localedef pt_BR -i pt_BR -f ISO-8859-1
localedef pt_BR.ISO-8859-1 -i pt_BR -f ISO-8859-1
localedef pt_BR.ISO8859-1 -i pt_BR -f ISO-8859-1
echo "na primeira tela selecione com a tecla spacebar pt_BR ISO-8859-1 e pt_BR.UTF-8 UTF-8"
echo "Com a tecla Tab navegue até OK e de ENTER"
echo "na segunda tela proceda da mesma maneira e selecione somente pt_BR.UTF-8"
echo "Pressione ENTER para continuar a instalação"
	read #pausa
dpkg-reconfigure locales
locale-gen --purge
locale-gen

########## Fim da adaptação da Distro ChaletOS ao sistema Brasileiro ###################

# Adicionando os repositórios para o java e postgreSQL 9.1
apt-add-repository -y ppa:webupd8team/java
wget --quiet -O - https://www.postgresql.org/media/keys/ACCC4CF8.asc | \
  apt-key add -
sh -c 'echo "deb http://apt.postgresql.org/pub/repos/apt/ xenial-pgdg main" >> /etc/apt/sources.list.d/postgresql.list'
apt -y update
apt -y install oracle-java8-installer
apt -y install apache2 apache2-utils authbind postgresql-9.1 libtcnative-1
ln -s /usr/lib/i386-linux-gnu/libtcnative-1.so /usr/lib/

cp /etc/postgresql/9.1/main/pg_hba.conf /etc/postgresql/9.1/main/pg_hba.conf.bak.original 
cp /etc/postgresql/9.1/main/postgresql.conf /etc/postgresql/9.1/main/postgresql.conf.bak.original 
cp ./files/pg_hba.conf /etc/postgresql/9.1/main/ 
chmod 644 /etc/postgresql/9.1/main/pg_hba.conf
cp ./files/postgresql.conf /etc/postgresql/9.1/main/
chmod 644 /etc/postgresql/9.1/main/postgresql.conf
cp ./files/biblivre5.conf /etc/apache2/conf-available/
chmod 644 /etc/apache2/conf-available/biblivre5.conf
a2enconf biblivre5
a2enmod proxy_http
a2enmod include
a2enmod actions
a2enmod ssl
a2enmod asis
sudo service apache2 reload

# Instalacao do tomcat 7.0.70 - mesma versao usada no Biblivre 5 windowsOS
wget http://archive.apache.org/dist/tomcat/tomcat-7/v7.0.70/bin/apache-tomcat-7.0.70.tar.gz
tar xvzf apache-tomcat-7.0.70.tar.gz
cp -r apache-tomcat-7.0.70 /opt
ln -s /opt/apache-tomcat-7.0.70 /opt/tomcat
wget https://jdbc.postgresql.org/download/postgresql-9.1-903.jdbc4.jar
cp postgresql-9.1-903.jdbc4.jar /opt/tomcat/lib
cp ./files/tomcat /etc/init.d
chmod +x /etc/init.d/tomcat
update-rc.d tomcat defaults
systemctl daemon-reload
cp ./files/*war /opt/tomcat/webapps
service tomcat start
chmod 777 /opt/tomcat/logs/catalina.out

# Instalacao da base de dados Biblivre 5
sudo -u postgres bash -c "psql < createdatabase.sql"
sudo -u postgres bash -c "psql biblivre4 < biblivre5.sql"

# instalacao do icone
cp ./files/Biblivre5.png /usr/share/icons/
desktop-file-install --dir=/usr/local/share/applications ./files/BiblivreV.desktop
# xdg-desktop-icon install --novendor /usr/local/share/applications/BiblivreV.desktop

# configuracao de acesso remoto
cp ./files/context.xml /opt/apache-tomcat-7.0.70/webapps/Biblivre4/META-INF
echo "Pressione ENTER e o arquivo de configuração se abrirá. Na ultima linha, insira o IP fixo do computador no lugar campo 000.000.000.000. Quando terminar a edição, salve e feche o arquivo e a instalação irá continuar."
      read #pausa
mousepad /opt/tomcat/webapps/Biblivre4/META-INF/context.xml
service tomcat restart
service postgresql restart
service apache2 restart

# Pacotes opcionais
apt -y install hplip-gui xrdp remmina intel-microcode gufw

# Upgrade do sistema
echo "lsb release = keep ou N (manter)"
echo "grub = update (versao do mantenedor do pacote)"
echo "50unattended-upgrades.ucftmp = update (versao do mantenedor do pacote)"
echo "Pressione ENTER para continuar"
	read #pausa
rm /etc/apt/apt.conf.d/50unattended-upgrades.ucf-dist
apt -y upgrade
apt -y autoremove

echo "Para acessar digite no seu navegador: localhost/Biblivre5"
echo "Atencao para o B maiusculo"
echo "OU"
echo "Clique no icone presente na Barra de Menus > Outros > Bibilivre"
echo "Pressione ENTER para reiniciar o computador"
	read #pausa
reboot
###########################################################################
# Change Log:
# 30/01/2017 - Script v1.1 - Resolvido o problema de restauração e geração de backups com a instalacao manual do Apache Tomcat na mesma versao da plataforma Microsoft.  
# Instalacao dos pacotes Java Oracle 8 e PostgreSQL-9.1 para maior compatibilidade. Adicao de icone no menu. Resolução de dependência do Apache Tomcat com a instalação do pacote libtcnative-1.
# Adicionado configuracao de rede para acesso remoto. Modificado por Renan Calliari.
# 07/06/2016 - Script v1.0: script inicial desenvolvido por Augusto Solfa.



